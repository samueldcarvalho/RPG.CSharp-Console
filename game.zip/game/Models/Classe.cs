namespace game.Models
{
  	public enum Classe {arqueiro,guerreiro,paladino,feiticeiro}
}